MA CAISSE — ETAPE 1 : PWA INSTALLABLE

1. Décompresse cette archive.
2. Publie les fichiers sur un hébergement HTTPS (GitHub Pages convient).
3. Ouvre le site dans Chrome sur Android.
4. Menu Chrome > Installer l'application / Ajouter à l'écran d'accueil.
5. Ouvre-la une première fois avec Internet, puis teste le mode avion.

Cette étape permet l'installation et le chargement hors connexion après la première visite.
Les données sont toujours locales à l'appareil. La synchronisation cloud multi-appareils sera développée ensuite.
